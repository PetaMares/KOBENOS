﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kobenos.category.test
{
    abstract class AbstractTest : AbstractNode, ITest
    {
        protected bool result;

        public override bool getResult()
        {
            return result;
        }

        public abstract void setConfiguration(string key, string value);
    }
}
