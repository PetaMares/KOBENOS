﻿using kobenos.category.test;
using System;
using System.Collections.Generic;
using System.Text;

namespace kobenos.category
{
    class InitializeTests
    {
        List<ICategory> categories = new List<ICategory>();
        public void initilize()
        {
            Category general = new Category("Všeobecná nastavení", "Všeobecná nastavení", "Všeobecná nastavení");
            ITest checkSystemTest = new CheckSystemTest("Kontrola verze Windows", "Kontrola verze Windows", "Kontrola typu a aktivace Windows");
            general.addTest(checkSystemTest);
            ITest section4Test = new Section4Test("Kontrola nastavení BIOS", "Kontrola nastavení BIOS/UEFI", "Kontrola nastavení BIOS/UEFI");
            general.addTest(section4Test);
            ITest section6Test = new Section6Test("Kontrola deaktivace ReadyBoost", "Kontrola deaktivace ReadyBoost", "Kontrola deaktivace ReadyBoost");
            general.addTest(section6Test);
            ITest section7Test = new Section7Test("Kontrola deaktivace WLAN", "Kontrola deaktivace WLAN", "Kontrola deaktivace WLAN");
            general.addTest(section7Test);
            ITest section8Test = new Section8Test("Kontrola deaktivace Bluetooth", "Kontrola deaktivace Bluetooth", "Kontrola deaktivace Bluetooth");
            general.addTest(section8Test);
            ITest section9Test = new Section9Test("Nastavení systémových služeb", "Nastavení systémových služeb", "Nastavení systémových služeb");
            general.addTest(section9Test);
            ITest section10Test = new Section10Test("Kontrola výchozího nastavení práv k souboru a složkám", "Kontrola výchozího nastavení práv k souboru a složkám", "Kontrola výchozího nastavení práv k souboru a složkám");
            general.addTest(section10Test);
            ITest section11Test = new Section11Test("Kontrola uživatelských účtů a skupin podle doporučené tabulky", "Kontrola uživatelských účtů a skupin podle doporučené tabulky", "Kontrola uživatelských účtů a skupin podle doporučené tabulky");
            general.addTest(section11Test);
            ITest section12Test = new Section12Test("Kontrola nastavení práv k tiskárnám", "Kontrola nastavení práv k tiskárnám", "Kontrola nastavení práv k tiskárnám");
            general.addTest(section12Test);
            ITest section13Test = new Section13Test("Kontrola odinstalovaných nepotřebných aplikací", "Kontrola odinstalovaných nepotřebných aplikací", "Potvrzovací okno, jestli byly odinstolovávány nepotřebné aplikace");
            general.addTest(section13Test);

            Category passwords = new Category("Hesla", "Hesla", "Hesla");
            ITest section14Test = new Section14Test("Kontrola zásad hesel", "Kontrola zásad hesel", "Kontrola zásad hesel");
            general.addTest(section14Test);
            ITest section15Test = new Section15Test("Kontrola zásad uzamčení účtů", "Kontrola zásad uzamčení účtů", "Kontrola zásad uzamčení účtů");
            general.addTest(section15Test);
        }
    }
}
