﻿using System;
using System.Management.Automation;
using System.Management.Automation.Runspaces;

namespace psh
{
    class Program
    {
        static void Main(string[] args)
        {
            var psCmd = "Get-Host";

            using var psHost = PowerShell.Create();
            psHost.AddScript(psCmd);

            var result = psHost.Invoke();

            foreach(var pSObject in result)
            {
                Console.WriteLine("-----------------");
                foreach(var property in pSObject.Properties)
                {
                    try
                    {
                    Console.WriteLine($"{property.Name} : {property.Value}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"{ex.GetType().FullName} : {ex.Message}");
                    }
                }
            }
        }
    }
}
